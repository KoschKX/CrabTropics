class Keyboard{
	LEFT;
	RIGHT;
	SPACE;
	ENTER;
}
