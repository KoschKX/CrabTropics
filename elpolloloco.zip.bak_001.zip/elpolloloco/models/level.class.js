class Level{
	enemies;
	clouds;
	sky;
	background;
	ground;

	constructor(enemies, clouds, sky, background, ground){
		this.enemies = enemies;
		this.clouds = clouds;
		this.sky = sky;
		this.background = background;
		this.ground = ground;
	}
}
